@echo off
echo Downloading Gradle wrapper jar...
powershell -Command "Invoke-WebRequest -Uri 'https://github.com/gradle/gradle/raw/v8.4.0/gradle/wrapper/gradle-wrapper.jar' -OutFile '%~dp0gradle-wrapper.jar' -UseBasicParsing"
if exist "%~dp0gradle-wrapper.jar" (
    echo Done!
) else (
    echo Failed. Trying alternative...
    powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/gradle/gradle/v8.4.0/gradle/wrapper/gradle-wrapper.jar' -OutFile '%~dp0gradle-wrapper.jar' -UseBasicParsing"
)
