package com.doctruyen.activities

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.doctruyen.R
import com.doctruyen.adapters.StoryAdapter
import com.doctruyen.databinding.ActivityMainBinding
import com.doctruyen.models.Story
import com.doctruyen.utils.AppPreferences
import com.doctruyen.utils.FileUtils
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPreferences
    private lateinit var adapter: StoryAdapter
    private var allStories = mutableListOf<Story>()
    private var filterMode = "all" // all, favorite, recent
    private var sortMode = "recent" // recent, name, progress

    private val openFileLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        var addedCount = 0
        for (uri in uris) {
            addStoryFromUri(uri)
            addedCount++
        }
        Toast.makeText(this, "Đã thêm $addedCount truyện", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        prefs = AppPreferences.getInstance(this)

        setupRecyclerView()
        setupSearch()
        setupFab()
        setupFilterChips()
        loadStories()
    }

    override fun onResume() {
        super.onResume()
        loadStories()
    }

    private fun setupRecyclerView() {
        adapter = StoryAdapter(
            onItemClick = { story -> openStory(story) },
            onItemLongClick = { story -> showContextMenu(story); true }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filterAndDisplay()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupFab() {
        binding.fabAdd.setOnClickListener {
            openFileLauncher.launch(arrayOf("text/plain", "text/*", "*/*"))
        }
    }

    private fun setupFilterChips() {
        binding.chipAll.setOnClickListener { filterMode = "all"; loadStories() }
        binding.chipFavorite.setOnClickListener { filterMode = "favorite"; loadStories() }
        binding.chipRecent.setOnClickListener { filterMode = "recent"; loadStories() }
    }

    private fun addStoryFromUri(uri: Uri) {
        try {
            // Persist permission
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) { /* ignore */ }

        val existingStories = prefs.getStories()
        val uriStr = uri.toString()

        // Check if already exists
        if (existingStories.any { it.fileUri == uriStr }) {
            Toast.makeText(this, "Truyện đã tồn tại trong danh sách", Toast.LENGTH_SHORT).show()
            return
        }

        val title = FileUtils.getFileNameFromUri(this, uri)
        val fileSize = FileUtils.getFileSizeFromUri(this, uri)

        val story = Story(
            id = UUID.randomUUID().toString(),
            title = title,
            filePath = uri.path ?: "",
            fileUri = uriStr,
            fileSize = fileSize,
            lastModified = System.currentTimeMillis()
        )

        // Count chars in background
        Thread {
            val totalChars = FileUtils.countCharsInUri(this, uri)
            story.totalChars = totalChars
            prefs.updateStory(story)
            runOnUiThread { loadStories() }
        }.start()

        prefs.updateStory(story)
        loadStories()
    }

    private fun loadStories() {
        allStories = prefs.getStories()
        filterAndDisplay()
        updateEmptyState()
    }

    private fun filterAndDisplay() {
        var list = allStories.toMutableList()

        // Filter
        when (filterMode) {
            "favorite" -> list = list.filter { it.isFavorite }.toMutableList()
            "recent" -> list = list.filter { it.lastOpenedTime > 0 }.toMutableList()
        }

        // Search
        val query = binding.etSearch.text.toString().trim().lowercase()
        if (query.isNotEmpty()) {
            list = list.filter { it.title.lowercase().contains(query) }.toMutableList()
        }

        // Sort
        list = when (sortMode) {
            "name" -> list.sortedBy { it.title }.toMutableList()
            "progress" -> list.sortedByDescending { it.readingProgress }.toMutableList()
            else -> list.sortedByDescending { it.lastOpenedTime }.toMutableList()
        }

        adapter.submitList(list)
        binding.tvCount.text = "${list.size} truyện"
        updateEmptyState()
    }

    private fun updateEmptyState() {
        if (allStories.isEmpty()) {
            binding.layoutEmpty.visibility = View.VISIBLE
            binding.recyclerView.visibility = View.GONE
        } else {
            binding.layoutEmpty.visibility = View.GONE
            binding.recyclerView.visibility = View.VISIBLE
        }
    }

    private fun openStory(story: Story) {
        val intent = Intent(this, ReaderActivity::class.java).apply {
            putExtra(ReaderActivity.EXTRA_STORY_ID, story.id)
        }
        startActivity(intent)
    }

    private fun showContextMenu(story: Story) {
        val popup = PopupMenu(this, binding.recyclerView)
        popup.menuInflater.inflate(R.menu.menu_story_context, popup.menu)
        popup.menu.findItem(R.id.action_favorite)?.title =
            if (story.isFavorite) "Bỏ yêu thích" else "Yêu thích"

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_open -> openStory(story)
                R.id.action_favorite -> toggleFavorite(story)
                R.id.action_rename -> showRenameDialog(story)
                R.id.action_reset_progress -> resetProgress(story)
                R.id.action_delete -> confirmDelete(story)
            }
            true
        }
        popup.show()
    }

    private fun toggleFavorite(story: Story) {
        story.isFavorite = !story.isFavorite
        prefs.updateStory(story)
        loadStories()
    }

    private fun showRenameDialog(story: Story) {
        val editText = EditText(this).apply {
            setText(story.title)
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Đổi tên truyện")
            .setView(editText)
            .setPositiveButton("Lưu") { _, _ ->
                val newTitle = editText.text.toString().trim()
                if (newTitle.isNotEmpty()) {
                    story.title = newTitle
                    prefs.updateStory(story)
                    loadStories()
                }
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun resetProgress(story: Story) {
        AlertDialog.Builder(this)
            .setTitle("Đặt lại tiến trình")
            .setMessage("Bạn có chắc muốn đặt lại tiến độ đọc của \"${story.title}\"?")
            .setPositiveButton("Đặt lại") { _, _ ->
                story.lastCharIndex = 0
                story.lastPosition = 0
                story.readingProgress = 0f
                story.lastOpenedTime = 0
                prefs.updateStory(story)
                loadStories()
                Toast.makeText(this, "Đã đặt lại tiến trình", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun confirmDelete(story: Story) {
        AlertDialog.Builder(this)
            .setTitle("Xóa truyện")
            .setMessage("Xóa \"${story.title}\" khỏi danh sách?\n(File gốc sẽ không bị xóa)")
            .setPositiveButton("Xóa") { _, _ ->
                prefs.removeStory(story.id)
                loadStories()
                Toast.makeText(this, "Đã xóa khỏi danh sách", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_sort_name -> { sortMode = "name"; filterAndDisplay(); true }
            R.id.action_sort_recent -> { sortMode = "recent"; filterAndDisplay(); true }
            R.id.action_sort_progress -> { sortMode = "progress"; filterAndDisplay(); true }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java)); true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
