package com.doctruyen.models

import java.io.Serializable

data class Story(
    val id: String,
    val title: String,
    val filePath: String,
    val fileUri: String,
    val fileSize: Long,
    val lastModified: Long,
    var lastPosition: Int = 0,
    var lastCharIndex: Long = 0L,
    var totalChars: Long = 0L,
    var lastOpenedTime: Long = 0L,
    var isFavorite: Boolean = false,
    var readingProgress: Float = 0f,
    var category: String = "Chưa phân loại"
) : Serializable {
    fun getProgressPercent(): Int {
        if (totalChars <= 0) return 0
        return ((lastCharIndex.toFloat() / totalChars.toFloat()) * 100).toInt()
    }

    fun getFileSizeDisplay(): String {
        return when {
            fileSize < 1024 -> "${fileSize}B"
            fileSize < 1024 * 1024 -> "${fileSize / 1024}KB"
            else -> String.format("%.1fMB", fileSize.toFloat() / (1024 * 1024))
        }
    }
}
