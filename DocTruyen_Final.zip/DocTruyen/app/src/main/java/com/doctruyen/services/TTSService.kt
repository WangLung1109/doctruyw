package com.doctruyen.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.MutableLiveData
import com.doctruyen.R
import com.doctruyen.activities.ReaderActivity
import com.doctruyen.utils.AppPreferences
import java.util.Locale

class TTSService : LifecycleService(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "tts_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_PLAY_PAUSE = "action_play_pause"
        const val ACTION_NEXT = "action_next"
        const val ACTION_PREV = "action_prev"
        const val ACTION_STOP = "action_stop"
        const val ACTION_SPEED_UP = "action_speed_up"
        const val ACTION_SPEED_DOWN = "action_speed_down"

        val isPlaying = MutableLiveData(false)
        val currentParagraphIndex = MutableLiveData(0)
        val ttsReady = MutableLiveData(false)
        val currentSentence = MutableLiveData("")
        val sleepTimerRemaining = MutableLiveData(0) // seconds remaining
    }

    private var tts: TextToSpeech? = null
    private var paragraphs: List<String> = emptyList()
    private var currentIndex = 0
    private var storyTitle = ""
    private var isPaused = false
    private var isStopped = false
    private lateinit var prefs: AppPreferences
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var sleepTimerJob: Thread? = null
    private var sleepTimerSeconds = 0
    private var onSentenceComplete: ((Int) -> Unit)? = null

    private val binder = TTSBinder()

    inner class TTSBinder : Binder() {
        fun getService(): TTSService = this@TTSService
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppPreferences.getInstance(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createNotificationChannel()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val vietnameseLocale = Locale("vi", "VN")
            val result = tts?.setLanguage(vietnameseLocale)
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                tts?.setLanguage(Locale.getDefault())
            }
            applyTTSSettings()
            setupUtteranceListener()
            ttsReady.postValue(true)
        }
    }

    private fun applyTTSSettings() {
        tts?.setSpeechRate(prefs.getTTSSpeed())
        tts?.setPitch(prefs.getTTSPitch())
    }

    private fun setupUtteranceListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                val idx = utteranceId?.toIntOrNull() ?: return
                currentParagraphIndex.postValue(idx)
                if (idx < paragraphs.size) {
                    currentSentence.postValue(paragraphs[idx])
                }
            }

            override fun onDone(utteranceId: String?) {
                val idx = utteranceId?.toIntOrNull() ?: return
                onSentenceComplete?.invoke(idx)
                if (!isStopped && !isPaused) {
                    val next = idx + 1
                    if (next < paragraphs.size) {
                        speakParagraph(next)
                    } else {
                        // Finished
                        isPlaying.postValue(false)
                        updateNotification()
                    }
                }
            }

            override fun onError(utteranceId: String?) {
                val idx = utteranceId?.toIntOrNull() ?: return
                val next = idx + 1
                if (!isStopped && !isPaused && next < paragraphs.size) {
                    speakParagraph(next)
                }
            }
        })
    }

    override fun onBind(intent: Intent): IBinder {
        super.onBind(intent)
        return binder
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> togglePlayPause()
            ACTION_NEXT -> nextParagraph()
            ACTION_PREV -> prevParagraph()
            ACTION_STOP -> stopTTS()
            ACTION_SPEED_UP -> adjustSpeed(0.1f)
            ACTION_SPEED_DOWN -> adjustSpeed(-0.1f)
        }
        return START_NOT_STICKY
    }

    fun loadStory(title: String, paragraphs: List<String>, startIndex: Int = 0) {
        this.storyTitle = title
        this.paragraphs = paragraphs
        this.currentIndex = startIndex
        currentParagraphIndex.postValue(startIndex)
    }

    fun setOnSentenceCompleteListener(listener: (Int) -> Unit) {
        this.onSentenceComplete = listener
    }

    fun startReading(fromIndex: Int = currentIndex) {
        if (paragraphs.isEmpty()) return
        requestAudioFocus()
        isStopped = false
        isPaused = false
        currentIndex = fromIndex.coerceIn(0, paragraphs.size - 1)
        isPlaying.postValue(true)
        speakParagraph(currentIndex)
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    fun togglePlayPause() {
        if (isPlaying.value == true) {
            pauseTTS()
        } else {
            resumeTTS()
        }
    }

    fun pauseTTS() {
        isPaused = true
        tts?.stop()
        isPlaying.postValue(false)
        updateNotification()
    }

    fun resumeTTS() {
        if (paragraphs.isEmpty()) return
        isPaused = false
        isStopped = false
        isPlaying.postValue(true)
        speakParagraph(currentIndex)
        updateNotification()
    }

    fun stopTTS() {
        isStopped = true
        isPaused = false
        tts?.stop()
        isPlaying.postValue(false)
        abandonAudioFocus()
        cancelSleepTimer()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    fun nextParagraph() {
        val next = currentIndex + 1
        if (next < paragraphs.size) {
            tts?.stop()
            currentIndex = next
            if (isPlaying.value == true) {
                speakParagraph(currentIndex)
            } else {
                currentParagraphIndex.postValue(currentIndex)
            }
        }
    }

    fun prevParagraph() {
        val prev = currentIndex - 1
        if (prev >= 0) {
            tts?.stop()
            currentIndex = prev
            if (isPlaying.value == true) {
                speakParagraph(currentIndex)
            } else {
                currentParagraphIndex.postValue(currentIndex)
            }
        }
    }

    fun seekTo(index: Int) {
        val clampedIndex = index.coerceIn(0, paragraphs.size - 1)
        tts?.stop()
        currentIndex = clampedIndex
        currentParagraphIndex.postValue(clampedIndex)
        if (isPlaying.value == true) {
            speakParagraph(currentIndex)
        }
    }

    fun setSpeed(speed: Float) {
        prefs.setTTSSpeed(speed)
        tts?.setSpeechRate(speed)
        updateNotification()
    }

    fun setPitch(pitch: Float) {
        prefs.setTTSPitch(pitch)
        tts?.setPitch(pitch)
    }

    fun adjustSpeed(delta: Float) {
        val current = prefs.getTTSSpeed()
        val newSpeed = (current + delta).coerceIn(0.3f, 3.0f)
        setSpeed(newSpeed)
    }

    fun getCurrentIndex(): Int = currentIndex

    fun setParagraphs(newParagraphs: List<String>) {
        paragraphs = newParagraphs
    }

    fun startSleepTimer(minutes: Int) {
        cancelSleepTimer()
        if (minutes <= 0) {
            sleepTimerRemaining.postValue(0)
            return
        }
        sleepTimerSeconds = minutes * 60
        sleepTimerRemaining.postValue(sleepTimerSeconds)
        sleepTimerJob = Thread {
            while (sleepTimerSeconds > 0 && !isStopped) {
                Thread.sleep(1000)
                sleepTimerSeconds--
                sleepTimerRemaining.postValue(sleepTimerSeconds)
                if (sleepTimerSeconds <= 0) {
                    pauseTTS()
                }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.interrupt()
        sleepTimerJob = null
        sleepTimerRemaining.postValue(0)
        sleepTimerSeconds = 0
    }

    private fun speakParagraph(index: Int) {
        if (index >= paragraphs.size || index < 0) return
        currentIndex = index
        val text = paragraphs[index]
        if (text.isBlank()) {
            val next = index + 1
            if (next < paragraphs.size && !isStopped && !isPaused) {
                speakParagraph(next)
            }
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, index.toString())
    }

    private fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener { focusChange ->
                    when (focusChange) {
                        AudioManager.AUDIOFOCUS_LOSS -> pauseTTS()
                        AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> pauseTTS()
                        AudioManager.AUDIOFOCUS_GAIN -> if (isPaused) resumeTTS()
                    }
                }
                .build()
            audioFocusRequest = focusRequest
            audioManager?.requestAudioFocus(focusRequest)
        }
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager?.abandonAudioFocusRequest(it) }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Đọc truyện",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Điều khiển đọc truyện"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, ReaderActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseIntent = PendingIntent.getService(
            this, 1,
            Intent(this, TTSService::class.java).apply { action = ACTION_PLAY_PAUSE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val prevIntent = PendingIntent.getService(
            this, 2,
            Intent(this, TTSService::class.java).apply { action = ACTION_PREV },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val nextIntent = PendingIntent.getService(
            this, 3,
            Intent(this, TTSService::class.java).apply { action = ACTION_NEXT },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 4,
            Intent(this, TTSService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val speedStr = String.format("%.1fx", prefs.getTTSSpeed())
        val playing = isPlaying.value == true
        val para = if (currentIndex < paragraphs.size) paragraphs[currentIndex].take(60) else ""

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(storyTitle.ifEmpty { "Đọc Truyện" })
            .setContentText(if (playing) para else "Đã tạm dừng")
            .setSubText("Tốc độ: $speedStr")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_previous, "Trước", prevIntent)
            .addAction(
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (playing) "Tạm dừng" else "Phát",
                playPauseIntent
            )
            .addAction(android.R.drawable.ic_media_next, "Tiếp", nextIntent)
            .addAction(android.R.drawable.ic_delete, "Dừng", stopIntent)
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .setOngoing(playing)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        abandonAudioFocus()
        cancelSleepTimer()
        isPlaying.postValue(false)
        ttsReady.postValue(false)
    }
}
