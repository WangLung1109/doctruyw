package com.doctruyen.activities

import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.doctruyen.databinding.ActivitySettingsBinding
import com.doctruyen.utils.AppPreferences

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: AppPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Cài đặt"
        }

        prefs = AppPreferences.getInstance(this)
        loadSettings()
        setupListeners()
    }

    private fun loadSettings() {
        // TTS Speed
        val speed = prefs.getTTSSpeed()
        binding.seekTTSSpeed.max = 27
        binding.seekTTSSpeed.progress = ((speed - 0.3f) / 0.1f).toInt()
        binding.tvTTSSpeed.text = String.format("%.1fx", speed)

        // TTS Pitch
        val pitch = prefs.getTTSPitch()
        binding.seekPitch.max = 20
        binding.seekPitch.progress = ((pitch - 0.5f) / 0.05f).toInt()
        binding.tvPitch.text = String.format("%.2f", pitch)

        // Font Size
        val fontSize = prefs.getFontSize()
        binding.seekFontSize.max = 20
        binding.seekFontSize.progress = (fontSize - 12).toInt()
        binding.tvFontSize.text = "${fontSize.toInt()}sp"

        // Theme
        val theme = prefs.getTheme()
        binding.rgTheme.check(
            when (theme) {
                "dark" -> com.doctruyen.R.id.rbDark
                "sepia" -> com.doctruyen.R.id.rbSepia
                "green" -> com.doctruyen.R.id.rbGreen
                else -> com.doctruyen.R.id.rbLight
            }
        )

        // Paragraphs per sentence
        val pps = prefs.getParagraphsPerSentence()
        binding.seekParagraphsPerSentence.max = 9
        binding.seekParagraphsPerSentence.progress = pps - 1
        binding.tvParagraphsPerSentence.text = "$pps đoạn/lần"
    }

    private fun setupListeners() {
        binding.seekTTSSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val speed = 0.3f + progress * 0.1f
                prefs.setTTSSpeed(speed)
                binding.tvTTSSpeed.text = String.format("%.1fx", speed)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        binding.seekPitch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val pitch = 0.5f + progress * 0.05f
                prefs.setTTSPitch(pitch)
                binding.tvPitch.text = String.format("%.2f", pitch)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        binding.seekFontSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val size = 12f + progress
                prefs.setFontSize(size)
                binding.tvFontSize.text = "${size.toInt()}sp"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        binding.rgTheme.setOnCheckedChangeListener { _, checkedId ->
            val theme = when (checkedId) {
                com.doctruyen.R.id.rbDark -> "dark"
                com.doctruyen.R.id.rbSepia -> "sepia"
                com.doctruyen.R.id.rbGreen -> "green"
                else -> "light"
            }
            prefs.setTheme(theme)
        }

        binding.seekParagraphsPerSentence.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val pps = progress + 1
                prefs.setParagraphsPerSentence(pps)
                binding.tvParagraphsPerSentence.text = "$pps đoạn/lần"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        binding.btnClearAll.setOnClickListener {
            // Clear all reading history
            val stories = prefs.getStories()
            stories.forEach { story ->
                story.lastCharIndex = 0
                story.lastPosition = 0
                story.readingProgress = 0f
                story.lastOpenedTime = 0
            }
            prefs.saveStories(stories)
            Toast.makeText(this, "Đã xóa toàn bộ lịch sử đọc", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
