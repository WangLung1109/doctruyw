package com.doctruyen.activities

import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Spannable
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.doctruyen.R
import com.doctruyen.databinding.ActivityReaderBinding
import com.doctruyen.models.Story
import com.doctruyen.services.TTSService
import com.doctruyen.utils.AppPreferences
import com.doctruyen.utils.FileUtils
import kotlinx.coroutines.*

class ReaderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_STORY_ID = "story_id"
        const val CHUNK_SIZE = 50_000 // chars per page
    }

    private lateinit var binding: ActivityReaderBinding
    private lateinit var prefs: AppPreferences
    private var story: Story? = null
    private var fullText: String = ""
    private var paragraphs: List<String> = emptyList()
    private var currentHighlightIndex = -1
    private var isServiceBound = false
    private var ttsService: TTSService? = null
    private var autoScrollJob: Job? = null
    private var isFullscreen = false
    private var isControlsVisible = true
    private val scope = CoroutineScope(Dispatchers.Main)
    private val saveHandler = Handler(Looper.getMainLooper())
    private var saveRunnable: Runnable? = null

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as TTSService.TTSBinder
            ttsService = binder.getService()
            isServiceBound = true

            val storyObj = story ?: return
            ttsService?.loadStory(storyObj.title, paragraphs, findParagraphIndex(storyObj.lastCharIndex))
            ttsService?.setOnSentenceCompleteListener { idx ->
                runOnUiThread { savePositionByParagraph(idx) }
            }

            observeTTSState()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            ttsService = null
            isServiceBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        prefs = AppPreferences.getInstance(this)

        val storyId = intent.getStringExtra(EXTRA_STORY_ID) ?: run {
            finish(); return
        }
        story = prefs.getStoryById(storyId) ?: run {
            Toast.makeText(this, "Không tìm thấy truyện", Toast.LENGTH_SHORT).show()
            finish(); return
        }

        applyTheme()
        applyFontSize()
        setupButtons()
        setupSpeedSlider()
        setupScrollListener()
        setupTapToToggle()

        loadStory()
    }

    private fun loadStory() {
        val storyObj = story ?: return
        binding.toolbar.title = storyObj.title
        binding.progressLoading.visibility = View.VISIBLE
        binding.tvContent.visibility = View.GONE

        scope.launch(Dispatchers.IO) {
            val uri = Uri.parse(storyObj.fileUri)
            val text = FileUtils.readTextFromUri(this@ReaderActivity, uri)

            if (text == null) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@ReaderActivity, "Không thể đọc file. File có thể đã bị xóa.", Toast.LENGTH_LONG).show()
                    binding.progressLoading.visibility = View.GONE
                }
                return@launch
            }

            fullText = text
            val totalChars = text.length.toLong()
            if (storyObj.totalChars != totalChars) {
                storyObj.totalChars = totalChars
            }

            paragraphs = FileUtils.splitToParagraphs(text)

            withContext(Dispatchers.Main) {
                binding.progressLoading.visibility = View.GONE
                binding.tvContent.visibility = View.VISIBLE
                displayContent()
                restorePosition()
                bindTTSService()
                updateProgress()
            }
        }
    }

    private fun displayContent() {
        binding.tvContent.text = fullText
    }

    private fun restorePosition() {
        val charIndex = story?.lastCharIndex ?: 0L
        if (charIndex > 0) {
            binding.scrollView.post {
                val layout = binding.tvContent.layout ?: return@post
                val line = layout.getLineForOffset(charIndex.toInt().coerceAtMost(fullText.length - 1))
                val y = layout.getLineTop(line)
                binding.scrollView.scrollTo(0, y)
            }
        }
    }

    private fun displayAndHighlightParagraph(index: Int) {
        if (index < 0 || index >= paragraphs.size || fullText.isEmpty()) return
        currentHighlightIndex = index

        val para = paragraphs[index]
        val charIndex = fullText.indexOf(para)
        if (charIndex < 0) return

        val spannable = SpannableString(fullText)
        spannable.setSpan(
            BackgroundColorSpan(getHighlightColor()),
            charIndex,
            (charIndex + para.length).coerceAtMost(fullText.length),
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        binding.tvContent.text = spannable

        // Scroll to highlight
        binding.scrollView.post {
            val layout = binding.tvContent.layout ?: return@post
            val line = layout.getLineForOffset(charIndex.coerceAtMost(fullText.length - 1))
            val y = (layout.getLineTop(line) - binding.scrollView.height / 3).coerceAtLeast(0)
            binding.scrollView.smoothScrollTo(0, y)
        }

        // Update progress
        savePositionByParagraph(index)
    }

    private fun getHighlightColor(): Int {
        return when (prefs.getTheme()) {
            "dark" -> Color.argb(120, 255, 200, 0)
            "sepia" -> Color.argb(120, 200, 100, 0)
            else -> Color.argb(120, 255, 200, 0)
        }
    }

    private fun findParagraphIndex(charIndex: Long): Int {
        if (paragraphs.isEmpty() || charIndex <= 0) return 0
        val targetChar = charIndex.toInt().coerceAtMost(fullText.length - 1)
        var accumulated = 0
        for ((i, para) in paragraphs.withIndex()) {
            val idx = fullText.indexOf(para, accumulated)
            if (idx >= 0 && idx >= targetChar) return i
            accumulated = idx + para.length
        }
        return 0
    }

    private fun savePositionByParagraph(paraIndex: Int) {
        if (paraIndex < 0 || paraIndex >= paragraphs.size || fullText.isEmpty()) return
        val para = paragraphs[paraIndex]
        val charIndex = fullText.indexOf(para).toLong().coerceAtLeast(0L)
        savePositionDelayed(charIndex)
    }

    private fun savePositionByScroll() {
        val scrollY = binding.scrollView.scrollY
        val layout = binding.tvContent.layout ?: return
        val line = layout.getLineForVertical(scrollY)
        val charOffset = layout.getLineStart(line).toLong()
        savePositionDelayed(charOffset)
    }

    private fun savePositionDelayed(charIndex: Long) {
        saveRunnable?.let { saveHandler.removeCallbacks(it) }
        saveRunnable = Runnable {
            val storyObj = story ?: return@Runnable
            storyObj.lastCharIndex = charIndex
            prefs.saveReadingPosition(storyObj.id, charIndex, storyObj.totalChars)
            updateProgress()
        }
        saveHandler.postDelayed(saveRunnable!!, 1000)
    }

    private fun updateProgress() {
        val storyObj = story ?: return
        val progress = storyObj.getProgressPercent()
        binding.progressBar.progress = progress
        binding.tvProgress.text = "$progress%"
        val pos = storyObj.lastCharIndex
        val total = storyObj.totalChars
        binding.tvCharCount.text = "${formatCount(pos)} / ${formatCount(total)}"
    }

    private fun formatCount(n: Long): String {
        return when {
            n < 1000 -> n.toString()
            n < 1_000_000 -> "${n / 1000}K"
            else -> String.format("%.1fM", n.toFloat() / 1_000_000)
        }
    }

    private fun bindTTSService() {
        val intent = Intent(this, TTSService::class.java)
        startService(intent)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun observeTTSState() {
        TTSService.isPlaying.observe(this) { playing ->
            updatePlayButton(playing)
        }
        TTSService.currentParagraphIndex.observe(this) { index ->
            displayAndHighlightParagraph(index)
        }
        TTSService.ttsReady.observe(this) { ready ->
            binding.btnPlayPause.isEnabled = ready
        }
        TTSService.sleepTimerRemaining.observe(this) { remaining ->
            if (remaining > 0) {
                val min = remaining / 60
                val sec = remaining % 60
                binding.tvSleepTimer.text = String.format("💤 %02d:%02d", min, sec)
                binding.tvSleepTimer.visibility = View.VISIBLE
            } else {
                binding.tvSleepTimer.visibility = View.GONE
            }
        }
    }

    private fun updatePlayButton(playing: Boolean) {
        val icon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        binding.btnPlayPause.setImageResource(icon)
    }

    private fun setupButtons() {
        binding.btnPlayPause.setOnClickListener {
            val service = ttsService ?: return@setOnClickListener
            if (TTSService.isPlaying.value == true) {
                service.pauseTTS()
            } else {
                if (paragraphs.isNotEmpty()) {
                    val startIdx = if (currentHighlightIndex >= 0) currentHighlightIndex else 0
                    service.loadStory(story?.title ?: "", paragraphs, startIdx)
                    service.startReading(startIdx)
                }
            }
        }

        binding.btnPrev.setOnClickListener { ttsService?.prevParagraph() }
        binding.btnNext.setOnClickListener { ttsService?.nextParagraph() }

        binding.btnStop.setOnClickListener {
            ttsService?.stopTTS()
            binding.tvContent.text = fullText
            currentHighlightIndex = -1
        }

        binding.btnSpeedDown.setOnClickListener {
            ttsService?.adjustSpeed(-0.1f)
            updateSpeedDisplay()
        }

        binding.btnSpeedUp.setOnClickListener {
            ttsService?.adjustSpeed(0.1f)
            updateSpeedDisplay()
        }

        binding.btnSleepTimer.setOnClickListener { showSleepTimerDialog() }

        binding.btnFontSize.setOnClickListener { showFontSizeDialog() }

        binding.btnTheme.setOnClickListener { cycleTheme() }

        binding.btnAutoScroll.setOnClickListener { toggleAutoScroll() }

        binding.btnJumpTo.setOnClickListener { showJumpToDialog() }
    }

    private fun setupSpeedSlider() {
        updateSpeedDisplay()
        binding.seekSpeed.max = 27 // 0.3 to 3.0 in steps of 0.1
        val currentSpeed = prefs.getTTSSpeed()
        binding.seekSpeed.progress = ((currentSpeed - 0.3f) / 0.1f).toInt()

        binding.seekSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val speed = 0.3f + progress * 0.1f
                    ttsService?.setSpeed(speed)
                    updateSpeedDisplay()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun updateSpeedDisplay() {
        val speed = prefs.getTTSSpeed()
        binding.tvSpeed.text = String.format("%.1fx", speed)
        val progress = ((speed - 0.3f) / 0.1f).toInt()
        binding.seekSpeed.progress = progress.coerceIn(0, 27)
    }

    private fun setupScrollListener() {
        binding.scrollView.viewTreeObserver.addOnScrollChangedListener {
            if (TTSService.isPlaying.value != true) {
                savePositionByScroll()
            }
        }
    }

    private fun setupTapToToggle() {
        binding.tvContent.setOnClickListener {
            toggleControls()
        }
    }

    private fun toggleControls() {
        isControlsVisible = !isControlsVisible
        val visibility = if (isControlsVisible) View.VISIBLE else View.GONE
        binding.layoutControls.visibility = visibility
        binding.toolbar.visibility = visibility
        binding.layoutBottomBar.visibility = visibility
    }

    private fun applyTheme() {
        val theme = prefs.getTheme()
        val (bg, text) = when (theme) {
            "dark" -> Pair(Color.parseColor("#1A1A2E"), Color.parseColor("#E8E8E8"))
            "sepia" -> Pair(Color.parseColor("#F5E6C8"), Color.parseColor("#3B2A1A"))
            "green" -> Pair(Color.parseColor("#1A2A1A"), Color.parseColor("#C8E8C8"))
            else -> Pair(Color.WHITE, Color.BLACK)
        }
        binding.root.setBackgroundColor(bg)
        binding.scrollView.setBackgroundColor(bg)
        binding.tvContent.setTextColor(text)
        binding.tvContent.setBackgroundColor(bg)
    }

    private fun applyFontSize() {
        binding.tvContent.textSize = prefs.getFontSize()
        binding.tvContent.lineSpacingMultiplier = 1.6f
    }

    private fun cycleTheme() {
        val themes = listOf("dark", "light", "sepia", "green")
        val current = prefs.getTheme()
        val next = themes[(themes.indexOf(current) + 1) % themes.size]
        prefs.setTheme(next)
        applyTheme()
        val names = mapOf("dark" to "Tối", "light" to "Sáng", "sepia" to "Sepia", "green" to "Xanh lá")
        Toast.makeText(this, "Giao diện: ${names[next]}", Toast.LENGTH_SHORT).show()
    }

    private fun showFontSizeDialog() {
        val sizes = arrayOf("14", "16", "18", "20", "22", "24", "26", "28")
        val current = prefs.getFontSize()
        val currentIdx = sizes.indexOfFirst { it.toFloat() == current }.coerceAtLeast(0)

        AlertDialog.Builder(this)
            .setTitle("Cỡ chữ")
            .setSingleChoiceItems(sizes, currentIdx) { dialog, which ->
                val size = sizes[which].toFloat()
                prefs.setFontSize(size)
                applyFontSize()
                dialog.dismiss()
            }
            .show()
    }

    private fun showSleepTimerDialog() {
        val options = arrayOf("Tắt", "5 phút", "10 phút", "15 phút", "20 phút", "30 phút", "45 phút", "60 phút")
        val minutes = arrayOf(0, 5, 10, 15, 20, 30, 45, 60)

        AlertDialog.Builder(this)
            .setTitle("Hẹn giờ tắt")
            .setItems(options) { _, which ->
                ttsService?.startSleepTimer(minutes[which])
                if (minutes[which] > 0) {
                    Toast.makeText(this, "Sẽ tạm dừng sau ${options[which]}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Đã tắt hẹn giờ", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showJumpToDialog() {
        val total = story?.totalChars ?: 0
        if (total <= 0) return

        val dialogView = layoutInflater.inflate(R.layout.dialog_jump_to, null)
        val seekBar = dialogView.findViewById<SeekBar>(R.id.seek_position)
        val tvPercent = dialogView.findViewById<TextView>(R.id.tv_percent)
        val current = story?.lastCharIndex ?: 0

        seekBar.max = 100
        val currentPercent = if (total > 0) ((current.toFloat() / total) * 100).toInt() else 0
        seekBar.progress = currentPercent
        tvPercent.text = "$currentPercent%"

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvPercent.text = "$progress%"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        AlertDialog.Builder(this)
            .setTitle("Nhảy đến vị trí")
            .setView(dialogView)
            .setPositiveButton("Đi đến") { _, _ ->
                val percent = seekBar.progress
                val targetChar = (total * percent / 100).toLong()
                jumpToChar(targetChar)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun jumpToChar(charIndex: Long) {
        if (fullText.isEmpty()) return
        val clampedIndex = charIndex.coerceIn(0, fullText.length.toLong() - 1).toInt()

        binding.scrollView.post {
            val layout = binding.tvContent.layout ?: return@post
            val line = layout.getLineForOffset(clampedIndex)
            val y = (layout.getLineTop(line) - binding.scrollView.height / 3).coerceAtLeast(0)
            binding.scrollView.scrollTo(0, y)
        }

        // Also jump TTS
        val paraIndex = findParagraphIndex(charIndex)
        ttsService?.seekTo(paraIndex)
        savePositionByScroll()
    }

    private fun toggleAutoScroll() {
        val isActive = autoScrollJob?.isActive == true
        if (isActive) {
            autoScrollJob?.cancel()
            binding.btnAutoScroll.setImageResource(android.R.drawable.ic_media_ff)
            Toast.makeText(this, "Đã tắt tự cuộn", Toast.LENGTH_SHORT).show()
        } else {
            showAutoScrollSpeedDialog()
        }
    }

    private fun showAutoScrollSpeedDialog() {
        val speeds = arrayOf("Chậm (1)", "Bình thường (2)", "Nhanh (3)", "Rất nhanh (4)", "Siêu nhanh (5)")
        AlertDialog.Builder(this)
            .setTitle("Tốc độ tự cuộn")
            .setItems(speeds) { _, which ->
                startAutoScroll(which + 1)
            }
            .show()
    }

    private fun startAutoScroll(speedLevel: Int) {
        autoScrollJob?.cancel()
        val delayMs = when (speedLevel) {
            1 -> 80L
            2 -> 50L
            3 -> 30L
            4 -> 20L
            else -> 10L
        }
        binding.btnAutoScroll.setImageResource(android.R.drawable.ic_media_pause)
        Toast.makeText(this, "Đang tự cuộn", Toast.LENGTH_SHORT).show()

        autoScrollJob = scope.launch {
            while (isActive) {
                delay(delayMs)
                withContext(Dispatchers.Main) {
                    binding.scrollView.scrollBy(0, 1)
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_reader, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> { onBackPressedDispatcher.onBackPressed(); true }
            R.id.action_fullscreen -> { toggleFullscreen(); true }
            R.id.action_go_to_start -> { jumpToChar(0); true }
            R.id.action_go_to_end -> { jumpToChar(fullText.length.toLong() - 1); true }
            R.id.action_pitch -> { showPitchDialog(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen
        if (isFullscreen) {
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
    }

    private fun showPitchDialog() {
        val pitches = arrayOf("0.5 (Rất trầm)", "0.7 (Trầm)", "0.9 (Hơi trầm)", "1.0 (Bình thường)", "1.1 (Hơi cao)", "1.3 (Cao)", "1.5 (Rất cao)")
        val values = arrayOf(0.5f, 0.7f, 0.9f, 1.0f, 1.1f, 1.3f, 1.5f)
        val current = prefs.getTTSPitch()
        val currentIdx = values.indexOfFirst { it == current }.coerceAtLeast(3)

        AlertDialog.Builder(this)
            .setTitle("Giọng đọc (pitch)")
            .setSingleChoiceItems(pitches, currentIdx) { dialog, which ->
                ttsService?.setPitch(values[which])
                dialog.dismiss()
                Toast.makeText(this, "Đã đổi giọng", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    override fun onPause() {
        super.onPause()
        savePositionByScroll()
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        autoScrollJob?.cancel()
        saveRunnable?.let { saveHandler.removeCallbacks(it) }
        if (isServiceBound) {
            unbindService(serviceConnection)
            isServiceBound = false
        }
    }
}
