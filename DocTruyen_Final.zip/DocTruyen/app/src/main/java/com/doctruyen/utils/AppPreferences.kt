package com.doctruyen.utils

import android.content.Context
import android.content.SharedPreferences
import com.doctruyen.models.Story
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class AppPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        const val PREF_NAME = "doc_truyen_prefs"
        const val KEY_STORIES = "stories_list"
        const val KEY_CURRENT_STORY_ID = "current_story_id"
        const val KEY_TTS_SPEED = "tts_speed"
        const val KEY_TTS_PITCH = "tts_pitch"
        const val KEY_FONT_SIZE = "font_size"
        const val KEY_THEME = "theme" // dark / light / sepia
        const val KEY_AUTO_SCROLL = "auto_scroll"
        const val KEY_AUTO_SCROLL_SPEED = "auto_scroll_speed"
        const val KEY_SLEEP_TIMER = "sleep_timer"
        const val KEY_READING_MODE = "reading_mode" // scroll / page
        const val KEY_PARAGRAPHS_PER_SENTENCE = "paragraphs_per_sentence"

        @Volatile
        private var instance: AppPreferences? = null

        fun getInstance(context: Context): AppPreferences {
            return instance ?: synchronized(this) {
                instance ?: AppPreferences(context.applicationContext).also { instance = it }
            }
        }
    }

    // --- Story List ---
    fun saveStories(stories: List<Story>) {
        prefs.edit().putString(KEY_STORIES, gson.toJson(stories)).apply()
    }

    fun getStories(): MutableList<Story> {
        val json = prefs.getString(KEY_STORIES, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<Story>>() {}.type
        return try {
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun updateStory(story: Story) {
        val stories = getStories()
        val index = stories.indexOfFirst { it.id == story.id }
        if (index >= 0) {
            stories[index] = story
        } else {
            stories.add(0, story)
        }
        saveStories(stories)
    }

    fun removeStory(storyId: String) {
        val stories = getStories()
        stories.removeAll { it.id == storyId }
        saveStories(stories)
    }

    fun getStoryById(id: String): Story? {
        return getStories().find { it.id == id }
    }

    // --- Reading Position ---
    fun saveReadingPosition(storyId: String, charIndex: Long, totalChars: Long) {
        prefs.edit()
            .putLong("pos_char_$storyId", charIndex)
            .putLong("pos_total_$storyId", totalChars)
            .apply()

        val stories = getStories()
        val story = stories.find { it.id == storyId }
        story?.let {
            it.lastCharIndex = charIndex
            it.totalChars = totalChars
            it.lastOpenedTime = System.currentTimeMillis()
            it.readingProgress = if (totalChars > 0) charIndex.toFloat() / totalChars else 0f
            saveStories(stories)
        }
    }

    fun getReadingPosition(storyId: String): Long {
        return prefs.getLong("pos_char_$storyId", 0L)
    }

    // --- TTS Settings ---
    fun getTTSSpeed(): Float = prefs.getFloat(KEY_TTS_SPEED, 1.0f)
    fun setTTSSpeed(speed: Float) = prefs.edit().putFloat(KEY_TTS_SPEED, speed).apply()

    fun getTTSPitch(): Float = prefs.getFloat(KEY_TTS_PITCH, 1.0f)
    fun setTTSPitch(pitch: Float) = prefs.edit().putFloat(KEY_TTS_PITCH, pitch).apply()

    // --- Display Settings ---
    fun getFontSize(): Float = prefs.getFloat(KEY_FONT_SIZE, 18f)
    fun setFontSize(size: Float) = prefs.edit().putFloat(KEY_FONT_SIZE, size).apply()

    fun getTheme(): String = prefs.getString(KEY_THEME, "dark") ?: "dark"
    fun setTheme(theme: String) = prefs.edit().putString(KEY_THEME, theme).apply()

    fun getReadingMode(): String = prefs.getString(KEY_READING_MODE, "scroll") ?: "scroll"
    fun setReadingMode(mode: String) = prefs.edit().putString(KEY_READING_MODE, mode).apply()

    // --- Auto Scroll ---
    fun isAutoScroll(): Boolean = prefs.getBoolean(KEY_AUTO_SCROLL, false)
    fun setAutoScroll(enabled: Boolean) = prefs.edit().putBoolean(KEY_AUTO_SCROLL, enabled).apply()

    fun getAutoScrollSpeed(): Int = prefs.getInt(KEY_AUTO_SCROLL_SPEED, 3)
    fun setAutoScrollSpeed(speed: Int) = prefs.edit().putInt(KEY_AUTO_SCROLL_SPEED, speed).apply()

    // --- Sleep Timer ---
    fun getSleepTimer(): Int = prefs.getInt(KEY_SLEEP_TIMER, 0) // minutes, 0 = off
    fun setSleepTimer(minutes: Int) = prefs.edit().putInt(KEY_SLEEP_TIMER, minutes).apply()

    // --- Current Story ---
    fun setCurrentStoryId(id: String) = prefs.edit().putString(KEY_CURRENT_STORY_ID, id).apply()
    fun getCurrentStoryId(): String? = prefs.getString(KEY_CURRENT_STORY_ID, null)

    // --- Paragraphs per TTS sentence ---
    fun getParagraphsPerSentence(): Int = prefs.getInt(KEY_PARAGRAPHS_PER_SENTENCE, 2)
    fun setParagraphsPerSentence(n: Int) = prefs.edit().putInt(KEY_PARAGRAPHS_PER_SENTENCE, n).apply()
}
