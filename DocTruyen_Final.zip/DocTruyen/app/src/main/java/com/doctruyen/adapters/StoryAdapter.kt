package com.doctruyen.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.doctruyen.R
import com.doctruyen.models.Story

class StoryAdapter(
    private val onItemClick: (Story) -> Unit,
    private val onItemLongClick: (Story) -> Boolean
) : ListAdapter<Story, StoryAdapter.StoryViewHolder>(StoryDiffCallback()) {

    inner class StoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val card: CardView = itemView.findViewById(R.id.card_story)
        val tvTitle: TextView = itemView.findViewById(R.id.tv_story_title)
        val tvSize: TextView = itemView.findViewById(R.id.tv_story_size)
        val tvProgress: TextView = itemView.findViewById(R.id.tv_story_progress)
        val tvLastOpened: TextView = itemView.findViewById(R.id.tv_last_opened)
        val progressBar: ProgressBar = itemView.findViewById(R.id.progress_bar)
        val ivFavorite: ImageView = itemView.findViewById(R.id.iv_favorite)
        val tvCategory: TextView = itemView.findViewById(R.id.tv_category)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_story, parent, false)
        return StoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: StoryViewHolder, position: Int) {
        val story = getItem(position)

        holder.tvTitle.text = story.title
        holder.tvSize.text = story.getFileSizeDisplay()

        val progress = story.getProgressPercent()
        holder.progressBar.progress = progress
        holder.tvProgress.text = if (progress > 0) "$progress%" else "Chưa đọc"

        // Format last opened time
        if (story.lastOpenedTime > 0) {
            val diff = System.currentTimeMillis() - story.lastOpenedTime
            holder.tvLastOpened.text = when {
                diff < 60_000 -> "Vừa xong"
                diff < 3_600_000 -> "${diff / 60_000} phút trước"
                diff < 86_400_000 -> "${diff / 3_600_000} giờ trước"
                diff < 2_592_000_000L -> "${diff / 86_400_000} ngày trước"
                else -> "Lâu rồi"
            }
            holder.tvLastOpened.visibility = View.VISIBLE
        } else {
            holder.tvLastOpened.visibility = View.GONE
        }

        holder.tvCategory.text = story.category
        holder.ivFavorite.visibility = if (story.isFavorite) View.VISIBLE else View.GONE

        holder.card.setOnClickListener { onItemClick(story) }
        holder.card.setOnLongClickListener { onItemLongClick(story) }
    }

    class StoryDiffCallback : DiffUtil.ItemCallback<Story>() {
        override fun areItemsTheSame(oldItem: Story, newItem: Story) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Story, newItem: Story) = oldItem == newItem
    }
}
