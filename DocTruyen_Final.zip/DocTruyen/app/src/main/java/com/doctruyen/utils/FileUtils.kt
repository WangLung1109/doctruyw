package com.doctruyen.utils

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.Charset

object FileUtils {

    fun readTextFromUri(context: Context, uri: Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            // Detect encoding
            val bytes = inputStream.readBytes()
            inputStream.close()

            // Try UTF-8 first, then fallback to common Vietnamese encodings
            val charsets = listOf("UTF-8", "UTF-16", "windows-1258", "ISO-8859-1")
            for (charsetName in charsets) {
                try {
                    val text = String(bytes, Charset.forName(charsetName))
                    if (!text.contains('\uFFFD') || charsetName == charsets.last()) {
                        return text
                    }
                } catch (e: Exception) {
                    continue
                }
            }
            String(bytes, Charsets.UTF_8)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun readChunkFromUri(context: Context, uri: Uri, startChar: Long, maxChars: Int): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
            reader.skip(startChar)
            val cbuf = CharArray(maxChars)
            val read = reader.read(cbuf)
            reader.close()
            if (read > 0) String(cbuf, 0, read) else null
        } catch (e: Exception) {
            null
        }
    }

    fun getFileNameFromUri(context: Context, uri: Uri): String {
        var name = "Không có tên"
        try {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0) {
                        name = it.getString(nameIndex) ?: name
                    }
                }
            }
        } catch (e: Exception) {
            // Try from path
            name = uri.lastPathSegment ?: name
        }
        return name.removeSuffix(".txt")
    }

    fun getFileSizeFromUri(context: Context, uri: Uri): Long {
        return try {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val sizeIndex = it.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex >= 0) it.getLong(sizeIndex) else 0L
                } else 0L
            } ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    fun countCharsInUri(context: Context, uri: Uri): Long {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return 0L
            val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
            var count = 0L
            val buffer = CharArray(8192)
            var read: Int
            while (reader.read(buffer).also { read = it } != -1) {
                count += read
            }
            reader.close()
            count
        } catch (e: Exception) {
            0L
        }
    }

    // Split text into paragraphs/sentences for TTS
    fun splitToParagraphs(text: String): List<String> {
        val paragraphs = mutableListOf<String>()
        val lines = text.split("\n")
        val current = StringBuilder()

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) {
                if (current.isNotEmpty()) {
                    paragraphs.add(current.toString().trim())
                    current.clear()
                }
            } else {
                if (current.isNotEmpty()) current.append(" ")
                current.append(trimmed)
                // Also split on sentence endings
                if (trimmed.endsWith(".") || trimmed.endsWith("!") || trimmed.endsWith("?") ||
                    trimmed.endsWith("…") || trimmed.length > 300
                ) {
                    paragraphs.add(current.toString().trim())
                    current.clear()
                }
            }
        }
        if (current.isNotEmpty()) {
            paragraphs.add(current.toString().trim())
        }
        return paragraphs.filter { it.isNotBlank() }
    }
}
